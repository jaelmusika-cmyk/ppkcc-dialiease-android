package com.example.dialiease2.fragments

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.setPadding
import androidx.fragment.app.Fragment
import com.example.dialiease2.databinding.FragmentScheduleBinding
import com.example.dialiease2.utils.Constants
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class ScheduleFragment : Fragment() {

    private var _binding: FragmentScheduleBinding? = null
    private val binding get() = _binding!!
    private val client = OkHttpClient()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentScheduleBinding.inflate(inflater, container, false)
        loadSchedule()
        return binding.root
    }

    private fun loadSchedule() {
        val sharedPref = requireActivity().getSharedPreferences("DialiEasePrefs", Context.MODE_PRIVATE)
        val email = sharedPref.getString("user_email", null)

        if (email == null) {
            if (_binding != null) {
                binding.scheduleStatus.text = "No email found"
            }
            return
        }

        val json = JSONObject().apply {
            put("email", email)
        }

        val body = json.toString().toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url(Constants.BASE_URL + "fetch_patient_schedule.php")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                requireActivity().runOnUiThread {
                    if (isAdded && _binding != null) {
                        binding.scheduleStatus.text = "Failed to load schedule"
                    }
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = JSONObject(response.body?.string() ?: "")
                requireActivity().runOnUiThread {
                    if (isAdded && _binding != null) {
                        val status = result.optString("schedule_status", "Pending")
                        binding.scheduleStatus.text = "Status: $status"

                        // Colorize status: green for Scheduled, gold for Pending
                        binding.scheduleStatus.setBackgroundColor(
                            if (status.lowercase() == "pending")
                                Color.parseColor("#FFD700")
                            else Color.parseColor("#4CAF50")
                        )

                        val schedules = result.optJSONArray("schedules")
                        binding.scheduleContainer.removeAllViews()

                        if (schedules != null && schedules.length() > 0) {
                            for (i in 0 until schedules.length()) {
                                val item = schedules.getJSONObject(i)
                                val view = createStyledScheduleView(
                                    item.getString("day"),
                                    item.getString("shift"),
                                    item.getString("start_time"),
                                    item.getString("duration")
                                )
                                binding.scheduleContainer.addView(view)
                            }
                        } else {
                            val emptyText = TextView(requireContext()).apply {
                                text = "No schedules yet"
                                textAlignment = View.TEXT_ALIGNMENT_CENTER
                            }
                            binding.scheduleContainer.addView(emptyText)
                        }
                    }
                }
            }
        })
    }

    private fun createStyledScheduleView(day: String, shift: String, startTime: String, duration: String): View {
        val context = requireContext()
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20)
            val shape = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 50f
                setColor(
                    if (shift == "First Shift")
                        Color.parseColor("#C8E6C9") // light green
                    else
                        Color.parseColor("#FFF9C4") // light gold
                )
            }
            background = shape
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 24)
            }
        }

        val start = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).parse(startTime)
        val startFormatted = SimpleDateFormat("h:mm a", Locale.getDefault()).format(start ?: Date())
        val durationInt = duration.toIntOrNull() ?: 0
        val endMillis = (start?.time ?: 0L) + durationInt * 60 * 1000
        val endFormatted = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(endMillis))

        val dayText = TextView(context).apply {
            text = day
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            textSize = 16f
            setTextColor(Color.BLACK)
        }

        val shiftText = TextView(context).apply {
            text = "$shift | $startFormatted to $endFormatted"
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            textSize = 14f
            setTextColor(Color.DKGRAY)
        }

        container.addView(dayText)
        container.addView(shiftText)

        return container
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
