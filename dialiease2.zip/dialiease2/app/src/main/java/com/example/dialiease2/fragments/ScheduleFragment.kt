package com.example.dialiease2.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.dialiease2.databinding.FragmentScheduleBinding
import com.example.dialiease2.utils.Constants
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

class ScheduleFragment : Fragment() {

    private var _binding: FragmentScheduleBinding? = null
    private val binding get() = _binding!!
    private val client = OkHttpClient()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentScheduleBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onResume() {
        super.onResume()
        fetchSchedule()
    }

    private fun fetchSchedule() {
        val sharedPref = requireActivity().getSharedPreferences("DialiEasePrefs", Context.MODE_PRIVATE)
        val email = sharedPref.getString("user_email", null)

        if (email == null) {
            binding.scheduleText.text = "No email found"
            return
        }

        val json = JSONObject().put("email", email)
        val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())

        val request = Request.Builder()
            .url(Constants.BASE_URL + "fetch_patient_schedule.php")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                activity?.runOnUiThread {
                    binding.scheduleText.text = "Error: ${e.message}"
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val resStr = response.body?.string()
                if (response.isSuccessful && resStr != null) {
                    val jsonRes = JSONObject(resStr)
                    if (jsonRes.getString("status") == "success") {
                        val s = jsonRes.getJSONObject("schedule")
                        val display = StringBuilder()
                        display.append("Status: ${s.getString("status")}\n\n")

                        val days = listOf("monday", "tuesday", "wednesday", "thursday", "friday", "saturday")
                        for (day in days) {
                            val shift = s.optString("${day}_shift", "")
                            val start = s.optString("${day}_start_time", "")
                            val duration = s.optString("${day}_duration", "")
                            if (shift.isNotEmpty()) {
                                display.append("${day.replaceFirstChar { it.uppercase() }}:\n")
                                display.append("  Shift: $shift\n")
                                display.append("  Start Time: $start\n")
                                display.append("  Duration: $duration minutes\n\n")
                            }
                        }

                        activity?.runOnUiThread {
                            binding.scheduleText.text = display.toString()
                        }
                    } else {
                        activity?.runOnUiThread {
                            binding.scheduleText.text = jsonRes.getString("message")
                        }
                    }
                }
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
