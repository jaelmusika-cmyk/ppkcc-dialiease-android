package com.example.dialiease2.fragments

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.setPadding
import androidx.fragment.app.Fragment
import com.example.dialiease2.R
import com.example.dialiease2.databinding.FragmentRequestBinding
import com.example.dialiease2.utils.Constants
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class RequestFragment : Fragment() {

    private var _binding: FragmentRequestBinding? = null
    private val binding get() = _binding!!
    private val client = OkHttpClient()
    private val currentSchedule = mutableMapOf<String, JSONObject>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRequestBinding.inflate(inflater, container, false)
        loadCurrentSchedule()

        binding.editCurrentScheduleBtn.setOnClickListener {
            showEditScheduleOptions()
        }

        binding.requestNewWeeklyBtn.setOnClickListener {
            showWeeklyScheduleDialog()
        }

        return binding.root
    }

    private fun loadCurrentSchedule() {
        val email = getEmail() ?: return
        val json = JSONObject().apply { put("email", email) }
        val body = json.toString().toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url(Constants.BASE_URL + "fetch_patient_schedule.php")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), "Failed to load schedule", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = JSONObject(response.body?.string() ?: "")
                val scheduleArray = result.optJSONArray("schedules")
                requireActivity().runOnUiThread {
                    currentSchedule.clear()
                    binding.currentScheduleList.removeAllViews()

                    if (scheduleArray != null && scheduleArray.length() > 0) {
                        for (i in 0 until scheduleArray.length()) {
                            val item = scheduleArray.getJSONObject(i)
                            val day = item.getString("day").lowercase()
                            currentSchedule[day] = item

                            val formatted = formatScheduleItem(item)
                            val row = TextView(requireContext()).apply {
                                text = formatted
                                setPadding(16)
                            }
                            binding.currentScheduleList.addView(row)
                        }
                    } else {
                        val empty = TextView(requireContext()).apply {
                            text = "No schedules yet"
                            setPadding(16)
                        }
                        binding.currentScheduleList.addView(empty)
                    }
                }
            }
        })
    }

    private fun getEmail(): String? {
        return requireActivity().getSharedPreferences("DialiEasePrefs", Context.MODE_PRIVATE)
            .getString("user_email", null)
    }

    private fun formatScheduleItem(item: JSONObject): String {
        val day = item.getString("day")
        val shift = item.getString("shift")
        val start = item.getString("start_time")
        val duration = item.getString("duration").toIntOrNull() ?: 0

        val startDate = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).parse(start)
        val startFormatted = SimpleDateFormat("h:mm a", Locale.getDefault()).format(startDate ?: Date())

        val endMillis = (startDate?.time ?: 0L) + duration * 60 * 1000
        val endFormatted = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(endMillis))

        return "$day | $shift | $startFormatted to $endFormatted"
    }

    private fun computeDurationMinutes(start: String, end: String): Int {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val s = sdf.parse(start)
        val e = sdf.parse(end)
        return ((e?.time ?: 0) - (s?.time ?: 0)).toInt() / (1000 * 60)
    }

    private fun isValidShiftTime(shift: String, start: String, end: String): Boolean {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val s = sdf.parse(start)?.time ?: return false
        val e = sdf.parse(end)?.time ?: return false

        val sHour = Calendar.getInstance().apply { timeInMillis = s }.get(Calendar.HOUR_OF_DAY)
        val eHour = Calendar.getInstance().apply { timeInMillis = e }.get(Calendar.HOUR_OF_DAY)

        return when (shift) {
            "First Shift" -> sHour in 6..9 && eHour in 7..10
            "Second Shift" -> sHour in 11..14 && eHour in 12..15
            else -> false
        }
    }

    private fun submitScheduleRequest(
        email: String,
        day: String,
        shift: String?,
        startTime: String?,
        duration: String?,
        note: String
    ) {
        val json = JSONObject().apply {
            put("email", email)
            put("day", day)
            put("shift", shift ?: JSONObject.NULL)
            put("start_time", startTime ?: JSONObject.NULL)
            put("duration", duration ?: JSONObject.NULL)
            put("note", note)
        }

        val body = json.toString().toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url(Constants.BASE_URL + "submit_schedule_request.php")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), "Request failed", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), "Request sent", Toast.LENGTH_SHORT).show()
                    loadCurrentSchedule()
                }
            }
        })
    }

    private fun showEditScheduleOptions() {
        val options = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()

        for ((day, _) in currentSchedule) {
            options.add("Edit ${day.replaceFirstChar { it.uppercase() }} Schedule")
            actions.add { showEditDayDialog(day) }
        }

        options.add("Add +")
        actions.add { showAddDayDialog() }

        AlertDialog.Builder(requireContext())
            .setTitle("Edit Current Schedule")
            .setItems(options.toTypedArray()) { _, which ->
                actions[which].invoke()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEditDayDialog(day: String) {
        val existing = currentSchedule[day] ?: return
        val dialogView = layoutInflater.inflate(R.layout.dialog_edit_day, null)
        val shiftSpinner = dialogView.findViewById<Spinner>(R.id.shiftSpinner)
        val startTimeInput = dialogView.findViewById<EditText>(R.id.startTimeInput)
        val endTimeInput = dialogView.findViewById<EditText>(R.id.endTimeInput)
        val clearButton = dialogView.findViewById<Button>(R.id.clearButton)

        shiftSpinner.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            listOf("First Shift", "Second Shift")
        )

        shiftSpinner.setSelection(if (existing.getString("shift") == "First Shift") 0 else 1)
        startTimeInput.setText(existing.getString("start_time").substring(0, 5))

        val start = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).parse(existing.getString("start_time"))
        val duration = existing.getString("duration").toIntOrNull() ?: 0
        val endTime = Date((start?.time ?: 0L) + duration * 60 * 1000)
        val endText = SimpleDateFormat("HH:mm", Locale.getDefault()).format(endTime)
        endTimeInput.setText(endText)

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("Edit ${day.replaceFirstChar { it.uppercase() }}")
            .setView(dialogView)
            .setPositiveButton("Submit Request", null)
            .setNegativeButton("Cancel", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val email = getEmail() ?: return@setOnClickListener
                val shift = shiftSpinner.selectedItem.toString()
                val start = startTimeInput.text.toString()
                val end = endTimeInput.text.toString()
                val duration = computeDurationMinutes(start, end)

                if (!isValidShiftTime(shift, start, end)) {
                    Toast.makeText(requireContext(), "Invalid time range", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                submitScheduleRequest(email, day, shift, "$start:00", duration.toString(), "")
                dialog.dismiss()
            }

            clearButton.setOnClickListener {
                val email = getEmail() ?: return@setOnClickListener
                submitScheduleRequest(email, day, null, null, null, "Requesting to clear schedule")
                dialog.dismiss()
            }
        }

        dialog.show()
    }

    private fun showAddDayDialog() {
        val allDays = listOf("monday", "tuesday", "wednesday", "thursday", "friday", "saturday")
        val unusedDays = allDays.filter { !currentSchedule.containsKey(it) }

        if (unusedDays.isEmpty()) {
            Toast.makeText(requireContext(), "All days already scheduled", Toast.LENGTH_SHORT).show()
            return
        }

        val dialogView = layoutInflater.inflate(R.layout.dialog_edit_day, null)
        val daySpinner = dialogView.findViewById<Spinner>(R.id.daySpinner)
        val shiftSpinner = dialogView.findViewById<Spinner>(R.id.shiftSpinner)
        val startTimeInput = dialogView.findViewById<EditText>(R.id.startTimeInput)
        val endTimeInput = dialogView.findViewById<EditText>(R.id.endTimeInput)

        daySpinner.visibility = View.VISIBLE
        daySpinner.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            unusedDays.map { it.replaceFirstChar { c -> c.uppercase() } }
        )

        shiftSpinner.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            listOf("First Shift", "Second Shift")
        )

        AlertDialog.Builder(requireContext())
            .setTitle("Add New Schedule Day")
            .setView(dialogView)
            .setPositiveButton("Submit Request") { _, _ ->
                val selectedDay = unusedDays[daySpinner.selectedItemPosition]
                val shift = shiftSpinner.selectedItem.toString()
                val start = startTimeInput.text.toString()
                val end = endTimeInput.text.toString()

                val duration = computeDurationMinutes(start, end)
                if (!isValidShiftTime(shift, start, end)) {
                    Toast.makeText(requireContext(), "Invalid time range", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val email = getEmail() ?: return@setPositiveButton
                submitScheduleRequest(email, selectedDay, shift, "$start:00", duration.toString(), "")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showWeeklyScheduleDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_request_weekly, null)
        val container = dialogView.findViewById<LinearLayout>(R.id.weeklyScheduleContainer)

        val dayViews = mutableMapOf<String, View>()
        val days = listOf("monday", "tuesday", "wednesday", "thursday", "friday", "saturday")

        for (day in days) {
            val row = layoutInflater.inflate(R.layout.dialog_edit_day, null)
            val dayLabel = TextView(requireContext()).apply {
                text = day.replaceFirstChar { it.uppercase() }
                textSize = 16f
                setPadding(0, 12, 0, 4)
            }
            row.findViewById<Spinner>(R.id.daySpinner)?.visibility = View.GONE
            container.addView(dayLabel)
            container.addView(row)
            dayViews[day] = row
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Request New Weekly Schedule")
            .setView(dialogView)
            .setPositiveButton("Submit Request") { _, _ ->
                val email = getEmail() ?: return@setPositiveButton

                for ((day, view) in dayViews) {
                    val shift = view.findViewById<Spinner>(R.id.shiftSpinner).selectedItem.toString()
                    val start = view.findViewById<EditText>(R.id.startTimeInput).text.toString()
                    val end = view.findViewById<EditText>(R.id.endTimeInput).text.toString()

                    if (start.isNotEmpty() && end.isNotEmpty()) {
                        val duration = computeDurationMinutes(start, end)
                        if (!isValidShiftTime(shift, start, end)) {
                            Toast.makeText(requireContext(), "$day has invalid time", Toast.LENGTH_SHORT).show()
                            return@setPositiveButton
                        }
                        submitScheduleRequest(email, day, shift, "$start:00", duration.toString(), "")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

