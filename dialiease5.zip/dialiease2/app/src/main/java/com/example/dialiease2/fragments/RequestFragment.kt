package com.example.dialiease2.fragments

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.setPadding
import androidx.fragment.app.Fragment
import com.example.dialiease2.R
import com.example.dialiease2.databinding.FragmentRequestBinding
import com.example.dialiease2.utils.Constants
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class RequestFragment : Fragment() {

    private var _binding: FragmentRequestBinding? = null
    private val binding get() = _binding!!
    private val client = OkHttpClient()
    private val currentSchedule = mutableMapOf<String, JSONObject>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRequestBinding.inflate(inflater, container, false)
        loadCurrentSchedule()

        binding.editCurrentScheduleBtn.setOnClickListener {
            showEditScheduleOptions()
        }

        binding.requestNewWeeklyBtn.setOnClickListener {
            showWeeklyScheduleDialog()
        }

        return binding.root
    }

    private fun showTimePicker(editText: EditText) {
        val cal = Calendar.getInstance()
        val timeSetListener = TimePickerDialog.OnTimeSetListener { _, hourOfDay, minute ->
            val selectedTime = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hourOfDay)
                set(Calendar.MINUTE, minute)
            }
            val formatted = SimpleDateFormat("h:mm", Locale.getDefault()).format(selectedTime.time)
            editText.setText(formatted)
        }

        TimePickerDialog(
            requireContext(), timeSetListener,
            cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false
        ).show()
    }

    private fun convertTo24Hour(time: String, ampm: String): String {
        val input = SimpleDateFormat("h:mm a", Locale.getDefault())
        val output = SimpleDateFormat("HH:mm", Locale.getDefault())
        return output.format(input.parse("$time $ampm") ?: Date())
    }


    private fun loadCurrentSchedule() {
        val email = getEmail() ?: return
        val json = JSONObject().apply { put("email", email) }
        val body = json.toString().toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url(Constants.BASE_URL + "fetch_patient_schedule.php")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), "Failed to load schedule", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = JSONObject(response.body?.string() ?: "")
                val scheduleArray = result.optJSONArray("schedules")
                requireActivity().runOnUiThread {
                    currentSchedule.clear()
                    binding.currentScheduleList.removeAllViews()

                    if (scheduleArray != null && scheduleArray.length() > 0) {
                        for (i in 0 until scheduleArray.length()) {
                            val item = scheduleArray.getJSONObject(i)
                            val day = item.getString("day").lowercase()
                            currentSchedule[day] = item

                            val formatted = formatScheduleItem(item)
                            val row = TextView(requireContext()).apply {
                                text = formatted
                                setPadding(16)
                            }
                            binding.currentScheduleList.addView(row)
                        }
                    } else {
                        val empty = TextView(requireContext()).apply {
                            text = "No schedules yet"
                            setPadding(16)
                        }
                        binding.currentScheduleList.addView(empty)
                    }
                }
            }
        })
    }

    private fun getEmail(): String? {
        return requireActivity().getSharedPreferences("DialiEasePrefs", Context.MODE_PRIVATE)
            .getString("user_email", null)
    }

    private fun formatScheduleItem(item: JSONObject): String {
        val day = item.getString("day")
        val shift = item.getString("shift")
        val start = item.getString("start_time")
        val duration = item.getString("duration").toIntOrNull() ?: 0

        val startDate = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).parse(start)
        val startFormatted = SimpleDateFormat("h:mm a", Locale.getDefault()).format(startDate ?: Date())
        val endMillis = (startDate?.time ?: 0L) + duration * 60 * 1000
        val endFormatted = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(endMillis))

        return "$day | $shift | $startFormatted to $endFormatted"
    }

    private fun computeDurationMinutes(start: String, end: String): Int {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val s = sdf.parse(start)
        val e = sdf.parse(end)
        return ((e?.time ?: 0) - (s?.time ?: 0)).toInt() / (1000 * 60)
    }

    private fun isValidShiftTime(shift: String, start: String, end: String): Boolean {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val sTime = sdf.parse(start)?.time ?: return false
        val eTime = sdf.parse(end)?.time ?: return false

        return when (shift) {
            "First Shift" -> {
                val minStart = sdf.parse("06:00")!!.time
                val maxEnd = sdf.parse("10:00")!!.time
                sTime in minStart..(maxEnd - 60 * 60 * 1000) && eTime in (sTime + 60 * 1000)..maxEnd
            }
            "Second Shift" -> {
                val minStart = sdf.parse("11:00")!!.time
                val maxEnd = sdf.parse("15:00")!!.time
                sTime in minStart..(maxEnd - 60 * 60 * 1000) && eTime in (sTime + 60 * 1000)..maxEnd
            }
            else -> false
        }
    }


    private fun submitScheduleRequest(
        email: String,
        day: String,
        shift: String?,
        startTime: String?,
        duration: String?,
        note: String,
        batchId: String? = null,
        replacesDay: String? = null
    ) {
        val json = JSONObject().apply {
            put("email", email)
            put("day", day)
            put("shift", shift ?: JSONObject.NULL)
            put("start_time", startTime ?: JSONObject.NULL)
            put("duration", duration ?: JSONObject.NULL)
            put("note", note)
            put("batch_id", batchId ?: JSONObject.NULL)
            if (replacesDay != null) put("replaces_day", replacesDay)
        }

        val body = json.toString().toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url(Constants.BASE_URL + "submit_schedule_request.php")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), "Request failed", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val resp = JSONObject(response.body?.string() ?: "")
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), resp.optString("message", "Request sent"), Toast.LENGTH_SHORT).show()
                    loadCurrentSchedule()
                }
            }
        })
    }



    private fun showEditScheduleOptions() {
        val options = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()

        for ((day, _) in currentSchedule) {
            options.add("Edit ${day.replaceFirstChar { it.uppercase() }} Schedule")
            actions.add { showEditDayDialog(day) }
        }

        options.add("Add +")
        actions.add { showAddDayDialog() }

        AlertDialog.Builder(requireContext())
            .setTitle("Edit Current Schedule")
            .setItems(options.toTypedArray()) { _, which -> actions[which].invoke() }
            .setNegativeButton("Cancel", null)
            .show()
    }



    private fun showEditDayDialog(day: String) {
        val existing = currentSchedule[day] ?: return
        val dialogView = layoutInflater.inflate(R.layout.dialog_edit_day, null)

        val daySpinner = dialogView.findViewById<Spinner>(R.id.daySpinner)
        val shiftSpinner = dialogView.findViewById<Spinner>(R.id.shiftSpinner)
        val startTimeInput = dialogView.findViewById<EditText>(R.id.startTimeInput)
        val endTimeInput = dialogView.findViewById<EditText>(R.id.endTimeInput)
        val startAmPmSpinner = dialogView.findViewById<Spinner>(R.id.startAmPmSpinner)
        val endAmPmSpinner = dialogView.findViewById<Spinner>(R.id.endAmPmSpinner)
        startTimeInput.setOnClickListener { showTimePicker(startTimeInput) }
        endTimeInput.setOnClickListener { showTimePicker(endTimeInput) }

        val clearButton = dialogView.findViewById<Button>(R.id.clearButton)

        val allDays = listOf("monday", "tuesday", "wednesday", "thursday", "friday", "saturday")
        daySpinner.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, allDays.map { it.replaceFirstChar { c -> c.uppercase() } })
        daySpinner.setSelection(allDays.indexOf(day))

        val shiftOptions = listOf("First Shift", "Second Shift")
        shiftSpinner.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, shiftOptions)

        val originalShift = existing.getString("shift")
        val rawOriginalStart = existing.getString("start_time").substring(0, 5)
        val originalStart = convertTo24Hour(SimpleDateFormat("h:mm", Locale.getDefault()).format(SimpleDateFormat("HH:mm").parse(rawOriginalStart)!!), "AM")
        val originalDuration = existing.getString("duration").toIntOrNull() ?: 0
        val startDate = SimpleDateFormat("HH:mm", Locale.getDefault()).parse(originalStart)
        val endMillis = (startDate?.time ?: 0L) + originalDuration * 60 * 1000
        val originalEnd = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(endMillis))

        val amPmFormat = SimpleDateFormat("a", Locale.getDefault())
        startTimeInput.setText(SimpleDateFormat("h:mm", Locale.getDefault()).format(startDate ?: Date()))
        startAmPmSpinner.setSelection(if (amPmFormat.format(startDate ?: Date()) == "AM") 0 else 1)
        endTimeInput.setText(SimpleDateFormat("h:mm", Locale.getDefault()).format(Date(endMillis)))
        endAmPmSpinner.setSelection(if (amPmFormat.format(Date(endMillis)) == "AM") 0 else 1)
        shiftSpinner.setSelection(shiftOptions.indexOf(originalShift))

        shiftSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                if (shiftOptions[pos] != originalShift) {
                    startTimeInput.setText("")
                    endTimeInput.setText("")
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }


        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("Edit ${day.replaceFirstChar { it.uppercase() }}")
            .setView(dialogView)
            .setPositiveButton("Submit Request", null)
            .setNegativeButton("Cancel", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val email = getEmail() ?: return@setOnClickListener
                val selectedDay = allDays[daySpinner.selectedItemPosition]
                val selectedShift = shiftSpinner.selectedItem.toString()
                val startRaw = startTimeInput.text.toString()
                val endRaw = endTimeInput.text.toString()
                val startAmPm = startAmPmSpinner.selectedItem.toString()
                val endAmPm = endAmPmSpinner.selectedItem.toString()

                if (startRaw.isBlank() || endRaw.isBlank()) {
                    Toast.makeText(requireContext(), "Start and end times are required", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val start24 = convertTo24Hour(startRaw, startAmPm)
                val end24 = convertTo24Hour(endRaw, endAmPm)
                val duration = computeDurationMinutes(start24, end24)

                val changed = selectedDay != day || selectedShift != originalShift || start24 != originalStart || end24 != originalEnd
                if (!changed) {
                    Toast.makeText(requireContext(), "No changes made", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                if (!isValidShiftTime(selectedShift, start24, end24)) {
                    Toast.makeText(requireContext(), "Invalid time range for $selectedShift", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                submitScheduleRequest(
                    email,
                    selectedDay,
                    selectedShift,
                    "$start24:00",
                    duration.toString(),
                    "Edit schedule",
                    null,
                    if (selectedDay != day) day else null
                )
                dialog.dismiss()
            }

            clearButton.setOnClickListener {
                val email = getEmail() ?: return@setOnClickListener
                submitScheduleRequest(email, day, null, null, null, "Requesting to clear schedule")
                dialog.dismiss()
            }
        }

        dialog.show()
    }




    private fun showAddDayDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_edit_day, null)
        val daySpinner = dialogView.findViewById<Spinner>(R.id.daySpinner)
        val shiftSpinner = dialogView.findViewById<Spinner>(R.id.shiftSpinner)
        val startTimeInput = dialogView.findViewById<EditText>(R.id.startTimeInput)
        val endTimeInput = dialogView.findViewById<EditText>(R.id.endTimeInput)
        startTimeInput.setOnClickListener { showTimePicker(startTimeInput) }
        endTimeInput.setOnClickListener { showTimePicker(endTimeInput) }
        val startAmPmSpinner = dialogView.findViewById<Spinner>(R.id.startAmPmSpinner)
        val endAmPmSpinner = dialogView.findViewById<Spinner>(R.id.endAmPmSpinner)
        val clearButton = dialogView.findViewById<Button>(R.id.clearButton)

        clearButton.visibility = View.GONE

        val allDays = listOf("monday", "tuesday", "wednesday", "thursday", "friday", "saturday")
        val availableDays = allDays.filterNot { currentSchedule.containsKey(it) }

        if (availableDays.isEmpty()) {
            Toast.makeText(requireContext(), "You already have schedules for all days.", Toast.LENGTH_SHORT).show()
            return
        }

        daySpinner.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, availableDays.map { it.replaceFirstChar { c -> c.uppercase() } })

        val shiftOptions = listOf("First Shift", "Second Shift")
        shiftSpinner.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, shiftOptions)

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("Add New Schedule")
            .setView(dialogView)
            .setPositiveButton("Submit Request", null)
            .setNegativeButton("Cancel", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val email = getEmail() ?: return@setOnClickListener
                val selectedDay = availableDays[daySpinner.selectedItemPosition]
                val selectedShift = shiftSpinner.selectedItem.toString()
                val startRaw = startTimeInput.text.toString()
                val endRaw = endTimeInput.text.toString()
                val startAmPm = startAmPmSpinner.selectedItem.toString()
                val endAmPm = endAmPmSpinner.selectedItem.toString()

                if (startRaw.isBlank() || endRaw.isBlank()) {
                    Toast.makeText(requireContext(), "Start and end times are required", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val start24 = convertTo24Hour(startRaw, startAmPm)
                val end24 = convertTo24Hour(endRaw, endAmPm)
                val duration = computeDurationMinutes(start24, end24)

                if (!isValidShiftTime(selectedShift, start24, end24)) {
                    Toast.makeText(requireContext(), "Invalid time range for $selectedShift", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                submitScheduleRequest(email, selectedDay, selectedShift, "$start24:00", duration.toString(), "Add new schedule")
                dialog.dismiss()
            }
        }

        dialog.show()
    }

    private fun showWeeklyScheduleDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_request_weekly, null)
        val dayIds = listOf("monday", "tuesday", "wednesday", "thursday", "friday", "saturday")

        val shiftIds = mapOf(
            "monday" to R.id.shiftSpinnerMonday,
            "tuesday" to R.id.shiftSpinnerTuesday,
            "wednesday" to R.id.shiftSpinnerWednesday,
            "thursday" to R.id.shiftSpinnerThursday,
            "friday" to R.id.shiftSpinnerFriday,
            "saturday" to R.id.shiftSpinnerSaturday
        )

        val startIds = mapOf(
            "monday" to R.id.startTimeInputMonday,
            "tuesday" to R.id.startTimeInputTuesday,
            "wednesday" to R.id.startTimeInputWednesday,
            "thursday" to R.id.startTimeInputThursday,
            "friday" to R.id.startTimeInputFriday,
            "saturday" to R.id.startTimeInputSaturday
        )

        val endIds = mapOf(
            "monday" to R.id.endTimeInputMonday,
            "tuesday" to R.id.endTimeInputTuesday,
            "wednesday" to R.id.endTimeInputWednesday,
            "thursday" to R.id.endTimeInputThursday,
            "friday" to R.id.endTimeInputFriday,
            "saturday" to R.id.endTimeInputSaturday
        )

        val startAmPmIds = mapOf(
            "monday" to R.id.startAmPmSpinnerMonday,
            "tuesday" to R.id.startAmPmSpinnerTuesday,
            "wednesday" to R.id.startAmPmSpinnerWednesday,
            "thursday" to R.id.startAmPmSpinnerThursday,
            "friday" to R.id.startAmPmSpinnerFriday,
            "saturday" to R.id.startAmPmSpinnerSaturday
        )

        val endAmPmIds = mapOf(
            "monday" to R.id.endAmPmSpinnerMonday,
            "tuesday" to R.id.endAmPmSpinnerTuesday,
            "wednesday" to R.id.endAmPmSpinnerWednesday,
            "thursday" to R.id.endAmPmSpinnerThursday,
            "friday" to R.id.endAmPmSpinnerFriday,
            "saturday" to R.id.endAmPmSpinnerSaturday
        )

        val shiftOptions = listOf("", "First Shift", "Second Shift")
        val inputMap = mutableMapOf<String, List<View>>()

        for (day in dayIds) {
            val shiftSpinner = dialogView.findViewById<Spinner>(shiftIds[day]!!)
            val startInput = dialogView.findViewById<EditText>(startIds[day]!!)
            val endInput = dialogView.findViewById<EditText>(endIds[day]!!)
            val startAmPm = dialogView.findViewById<Spinner>(startAmPmIds[day]!!)
            val endAmPm = dialogView.findViewById<Spinner>(endAmPmIds[day]!!)

            shiftSpinner.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, shiftOptions)
            startInput.setOnClickListener { showTimePicker(startInput) }
            endInput.setOnClickListener { showTimePicker(endInput) }

            inputMap[day] = listOf(shiftSpinner, startInput, endInput, startAmPm, endAmPm)
        }

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("Request New Weekly Schedule")
            .setView(dialogView)
            .setPositiveButton("Submit", null)
            .setNegativeButton("Cancel", null)
            .create()

        dialog.setOnShowListener {
            val batchId = System.currentTimeMillis().toString()
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val email = getEmail() ?: return@setOnClickListener
                val existingDays = currentSchedule.keys.map { it.lowercase() }.toSet()
                val submittedDays = mutableSetOf<String>()
                var valid = false

                for ((day, views) in inputMap) {
                    val shift = (views[0] as Spinner).selectedItem.toString()
                    val startRaw = (views[1] as EditText).text.toString()
                    val endRaw = (views[2] as EditText).text.toString()
                    val startAmPm = (views[3] as Spinner).selectedItem.toString()
                    val endAmPm = (views[4] as Spinner).selectedItem.toString()

                    if (shift.isNotBlank() && startRaw.isNotBlank() && endRaw.isNotBlank()) {
                        if (submittedDays.contains(day)) {
                            Toast.makeText(requireContext(), "Duplicate entry for $day", Toast.LENGTH_SHORT).show()
                            return@setOnClickListener
                        }

                        if (existingDays.contains(day)) {
                            Toast.makeText(requireContext(), "Pending request already exists for $day", Toast.LENGTH_SHORT).show()
                            return@setOnClickListener
                        }

                        val start24 = convertTo24Hour(startRaw, startAmPm)
                        val end24 = convertTo24Hour(endRaw, endAmPm)
                        val duration = computeDurationMinutes(start24, end24)

                        if (!isValidShiftTime(shift, start24, end24)) {
                            Toast.makeText(requireContext(), "Invalid time for $day - $shift", Toast.LENGTH_SHORT).show()
                            return@setOnClickListener
                        }

                        valid = true
                        submittedDays.add(day)

                        submitScheduleRequest(email, day, shift, "$start24:00", duration.toString(), "Weekly schedule request", batchId)
                    }
                }

                if (valid) {
                    Toast.makeText(requireContext(), "Requests submitted", Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                } else {
                    Toast.makeText(requireContext(), "Please fill in at least one valid schedule", Toast.LENGTH_SHORT).show()
                }
            }
        }

        dialog.show()
    }





    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

