package com.example.dialiease2.fragments

import android.app.AlertDialog
import android.content.Context
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.view.setPadding
import androidx.fragment.app.Fragment
import com.example.dialiease2.R
import com.example.dialiease2.databinding.FragmentRequestBinding
import com.example.dialiease2.utils.Constants
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class RequestFragment : Fragment() {

    private var _binding: FragmentRequestBinding? = null
    private val binding get() = _binding!!
    private val client = OkHttpClient()
    private val currentSchedule = mutableMapOf<String, JSONObject>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRequestBinding.inflate(inflater, container, false)
        loadCurrentSchedule()

        binding.editCurrentScheduleBtn.setOnClickListener {
            showEditScheduleOptions()
        }

        binding.requestNewWeeklyBtn.setOnClickListener {
            showWeeklyScheduleDialog()
        }

        return binding.root
    }

    private fun showTimePicker(editText: EditText) {
        val cal = Calendar.getInstance()
        TimePickerDialog(requireContext(), { _, hour, minute ->
            editText.setText(String.format("%02d:%02d", hour, minute))
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
    }

    private fun loadCurrentSchedule() {
        val email = getEmail() ?: return
        val json = JSONObject().apply { put("email", email) }
        val body = json.toString().toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url(Constants.BASE_URL + "fetch_patient_schedule.php")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), "Failed to load schedule", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val result = JSONObject(response.body?.string() ?: "")
                val scheduleArray = result.optJSONArray("schedules")
                requireActivity().runOnUiThread {
                    currentSchedule.clear()
                    binding.currentScheduleList.removeAllViews()

                    if (scheduleArray != null && scheduleArray.length() > 0) {
                        for (i in 0 until scheduleArray.length()) {
                            val item = scheduleArray.getJSONObject(i)
                            val day = item.getString("day").lowercase()
                            currentSchedule[day] = item

                            val formatted = formatScheduleItem(item)
                            val row = TextView(requireContext()).apply {
                                text = formatted
                                setPadding(16)
                            }
                            binding.currentScheduleList.addView(row)
                        }
                    } else {
                        val empty = TextView(requireContext()).apply {
                            text = "No schedules yet"
                            setPadding(16)
                        }
                        binding.currentScheduleList.addView(empty)
                    }
                }
            }
        })
    }

    private fun getEmail(): String? {
        return requireActivity().getSharedPreferences("DialiEasePrefs", Context.MODE_PRIVATE)
            .getString("user_email", null)
    }

    private fun formatScheduleItem(item: JSONObject): String {
        val day = item.getString("day")
        val shift = item.getString("shift")
        val start = item.getString("start_time")
        val duration = item.getString("duration").toIntOrNull() ?: 0

        val startDate = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).parse(start)
        val startFormatted = SimpleDateFormat("h:mm a", Locale.getDefault()).format(startDate ?: Date())

        val endMillis = (startDate?.time ?: 0L) + duration * 60 * 1000
        val endFormatted = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(endMillis))

        return "$day | $shift | $startFormatted to $endFormatted"
    }

    private fun computeDurationMinutes(start: String, end: String): Int {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val s = sdf.parse(start)
        val e = sdf.parse(end)
        return ((e?.time ?: 0) - (s?.time ?: 0)).toInt() / (1000 * 60)
    }

    private fun isValidShiftTime(shift: String, start: String, end: String): Boolean {
        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val s = sdf.parse(start)?.time ?: return false
        val e = sdf.parse(end)?.time ?: return false

        val sHour = Calendar.getInstance().apply { timeInMillis = s }.get(Calendar.HOUR_OF_DAY)
        val eHour = Calendar.getInstance().apply { timeInMillis = e }.get(Calendar.HOUR_OF_DAY)

        return when (shift) {
            "First Shift" -> sHour in 6..9 && eHour in 7..10
            "Second Shift" -> sHour in 11..14 && eHour in 12..15
            else -> false
        }
    }

    private fun submitScheduleRequest(
        email: String,
        day: String,
        shift: String?,
        startTime: String?,
        duration: String?,
        note: String
    ) {
        val json = JSONObject().apply {
            put("email", email)
            put("day", day)
            put("shift", shift ?: JSONObject.NULL)
            put("start_time", startTime ?: JSONObject.NULL)
            put("duration", duration ?: JSONObject.NULL)
            put("note", note)
        }

        val body = json.toString().toRequestBody("application/json".toMediaTypeOrNull())
        val request = Request.Builder()
            .url(Constants.BASE_URL + "submit_schedule_request.php")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), "Request failed", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), "Request sent", Toast.LENGTH_SHORT).show()
                    loadCurrentSchedule()
                }
            }
        })
    }

    private fun showEditScheduleOptions() {
        val options = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()

        for ((day, _) in currentSchedule) {
            options.add("Edit ${day.replaceFirstChar { it.uppercase() }} Schedule")
            actions.add { showEditDayDialog(day) }
        }

        options.add("Add +")
        actions.add { showAddDayDialog() }

        AlertDialog.Builder(requireContext())
            .setTitle("Edit Current Schedule")
            .setItems(options.toTypedArray()) { _, which ->
                actions[which].invoke()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEditDayDialog(day: String) {
        val existing = currentSchedule[day] ?: return
        val dialogView = layoutInflater.inflate(R.layout.dialog_edit_day, null)
        val daySpinner = dialogView.findViewById<Spinner>(R.id.daySpinner)
        val shiftSpinner = dialogView.findViewById<Spinner>(R.id.shiftSpinner)
        val startTimeInput = dialogView.findViewById<EditText>(R.id.startTimeInput)
        val endTimeInput = dialogView.findViewById<EditText>(R.id.endTimeInput)
        val clearButton = dialogView.findViewById<Button>(R.id.clearButton)

        val allDays = listOf("monday", "tuesday", "wednesday", "thursday", "friday", "saturday")
        daySpinner.visibility = View.VISIBLE
        daySpinner.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, allDays.map { it.replaceFirstChar { c -> c.uppercase() } })
        daySpinner.setSelection(allDays.indexOf(day))

        val shiftOptions = listOf("First Shift", "Second Shift")
        shiftSpinner.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, shiftOptions)

        val originalShift = existing.getString("shift")
        val originalStart = existing.getString("start_time").substring(0, 5)
        val originalDuration = existing.getString("duration").toIntOrNull() ?: 0
        val startDate = SimpleDateFormat("HH:mm", Locale.getDefault()).parse(originalStart)
        val endMillis = (startDate?.time ?: 0L) + originalDuration * 60 * 1000
        val originalEnd = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(endMillis))

        shiftSpinner.setSelection(shiftOptions.indexOf(originalShift))
        startTimeInput.setText(originalStart)
        endTimeInput.setText(originalEnd)

        startTimeInput.setOnClickListener { showTimePicker(startTimeInput) }
        endTimeInput.setOnClickListener { showTimePicker(endTimeInput) }

        shiftSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                val selectedShift = shiftOptions[pos]
                if (selectedShift != originalShift) {
                    startTimeInput.setText("")
                    endTimeInput.setText("")
                } else {
                    startTimeInput.setText(originalStart)
                    endTimeInput.setText(originalEnd)
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("Edit ${day.replaceFirstChar { it.uppercase() }}")
            .setView(dialogView)
            .setPositiveButton("Submit Request", null)
            .setNegativeButton("Cancel", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val email = getEmail() ?: return@setOnClickListener
                val selectedDay = allDays[daySpinner.selectedItemPosition]
                val selectedShift = shiftSpinner.selectedItem.toString()
                val start = startTimeInput.text.toString()
                val end = endTimeInput.text.toString()

                if (start.isBlank() || end.isBlank()) {
                    Toast.makeText(requireContext(), "Start and end times are required", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val duration = computeDurationMinutes(start, end)
                if (!isValidShiftTime(selectedShift, start, end)) {
                    Toast.makeText(requireContext(), "Invalid time range for $selectedShift", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val changed = selectedShift != originalShift || start != originalStart || end != originalEnd || selectedDay != day
                if (!changed) {
                    Toast.makeText(requireContext(), "No changes made", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                submitScheduleRequest(email, selectedDay, selectedShift, "$start:00", duration.toString(), "Edit schedule")
                dialog.dismiss()
            }

            clearButton.visibility = View.VISIBLE
            clearButton.setOnClickListener {
                val email = getEmail() ?: return@setOnClickListener
                submitScheduleRequest(email, day, null, null, null, "Requesting to clear schedule")
                dialog.dismiss()
            }
        }

        dialog.show()
    }


    private fun showAddDayDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_edit_day, null)
        val daySpinner = dialogView.findViewById<Spinner>(R.id.daySpinner)
        val shiftSpinner = dialogView.findViewById<Spinner>(R.id.shiftSpinner)
        val startTimeInput = dialogView.findViewById<EditText>(R.id.startTimeInput)
        val endTimeInput = dialogView.findViewById<EditText>(R.id.endTimeInput)
        val clearButton = dialogView.findViewById<Button>(R.id.clearButton)
        clearButton.visibility = View.GONE

        val allDays = listOf("monday", "tuesday", "wednesday", "thursday", "friday", "saturday")
        val availableDays = allDays.filterNot { currentSchedule.containsKey(it) }

        if (availableDays.isEmpty()) {
            Toast.makeText(requireContext(), "You already have schedules for all days.", Toast.LENGTH_SHORT).show()
            return
        }

        daySpinner.visibility = View.VISIBLE
        daySpinner.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, availableDays.map { it.replaceFirstChar { c -> c.uppercase() } })

        val shiftOptions = listOf("First Shift", "Second Shift")
        shiftSpinner.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, shiftOptions)

        startTimeInput.setOnClickListener { showTimePicker(startTimeInput) }
        endTimeInput.setOnClickListener { showTimePicker(endTimeInput) }

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("Add New Schedule")
            .setView(dialogView)
            .setPositiveButton("Submit Request", null)
            .setNegativeButton("Cancel", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val email = getEmail() ?: return@setOnClickListener
                val selectedDay = availableDays[daySpinner.selectedItemPosition]
                val selectedShift = shiftSpinner.selectedItem.toString()
                val start = startTimeInput.text.toString()
                val end = endTimeInput.text.toString()

                if (start.isBlank() || end.isBlank()) {
                    Toast.makeText(requireContext(), "Start and end times are required", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                val duration = computeDurationMinutes(start, end)
                if (!isValidShiftTime(selectedShift, start, end)) {
                    Toast.makeText(requireContext(), "Invalid time range for $selectedShift", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                submitScheduleRequest(email, selectedDay, selectedShift, "$start:00", duration.toString(), "Add new schedule")
                dialog.dismiss()
            }
        }

        dialog.show()
    }


    private fun showWeeklyScheduleDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_request_weekly, null)
        val dayIds = listOf("monday", "tuesday", "wednesday", "thursday", "friday", "saturday")

        val shiftIds = mapOf(
            "monday" to R.id.shiftSpinnerMonday,
            "tuesday" to R.id.shiftSpinnerTuesday,
            "wednesday" to R.id.shiftSpinnerWednesday,
            "thursday" to R.id.shiftSpinnerThursday,
            "friday" to R.id.shiftSpinnerFriday,
            "saturday" to R.id.shiftSpinnerSaturday
        )

        val startIds = mapOf(
            "monday" to R.id.startTimeInputMonday,
            "tuesday" to R.id.startTimeInputTuesday,
            "wednesday" to R.id.startTimeInputWednesday,
            "thursday" to R.id.startTimeInputThursday,
            "friday" to R.id.startTimeInputFriday,
            "saturday" to R.id.startTimeInputSaturday
        )

        val endIds = mapOf(
            "monday" to R.id.endTimeInputMonday,
            "tuesday" to R.id.endTimeInputTuesday,
            "wednesday" to R.id.endTimeInputWednesday,
            "thursday" to R.id.endTimeInputThursday,
            "friday" to R.id.endTimeInputFriday,
            "saturday" to R.id.endTimeInputSaturday
        )

        val shiftOptions = listOf("", "First Shift", "Second Shift")
        val inputMap = mutableMapOf<String, Triple<Spinner, EditText, EditText>>()

        for (day in dayIds) {
            val shiftSpinner = dialogView.findViewById<Spinner>(shiftIds[day]!!)
            val startInput = dialogView.findViewById<EditText>(startIds[day]!!)
            val endInput = dialogView.findViewById<EditText>(endIds[day]!!)

            shiftSpinner.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, shiftOptions)
            startInput.setOnClickListener { showTimePicker(startInput) }
            endInput.setOnClickListener { showTimePicker(endInput) }

            inputMap[day] = Triple(shiftSpinner, startInput, endInput)
        }

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("Request New Weekly Schedule")
            .setView(dialogView)
            .setPositiveButton("Submit", null)
            .setNegativeButton("Cancel", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val email = getEmail() ?: return@setOnClickListener
                var valid = false

                for ((day, triple) in inputMap) {
                    val shift = triple.first.selectedItem.toString()
                    val start = triple.second.text.toString()
                    val end = triple.third.text.toString()

                    if (shift.isNotBlank() && start.isNotBlank() && end.isNotBlank()) {
                        val duration = computeDurationMinutes(start, end)
                        if (isValidShiftTime(shift, start, end)) {
                            valid = true
                            submitScheduleRequest(email, day, shift, "$start:00", duration.toString(), "Weekly schedule request")
                        }
                    }
                }

                if (valid) {
                    Toast.makeText(requireContext(), "Requests submitted", Toast.LENGTH_SHORT).show()
                    dialog.dismiss()
                } else {
                    Toast.makeText(requireContext(), "Please fill in at least one valid schedule", Toast.LENGTH_SHORT).show()
                }
            }
        }

        dialog.show()
    }



    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

